@extends('layouts.app')

@section('content')
    @include('sections.hero')
    @include('sections.for-who')
    @include('sections.offer-teaser')
    @include('sections.reviews-teaser')
    @include('sections.faq-teaser')
    @include('sections.contact-teaser')
@endsection
