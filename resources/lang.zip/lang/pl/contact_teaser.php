<?php
return [
  'h2' => 'Umów się na krótką rozmowę poziomującą, podczas której porozmawiamy o Twoich celach i dobierzemy kurs dopasowany do Twoich potrzeb.',
  'cta' => 'Umów rozmowę',
];