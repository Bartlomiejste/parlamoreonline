<?php
return [
  'h2' => 'Dla kogo są te zajęcia?',
  'lead' => 'Moje lekcje są dla osób, które chcą:',
  'bullets' => [
    'Mówić swobodnie po polsku lub po włosku w codziennych sytuacjach.',
    'Przełamać barierę językową w pracy, w szkole lub w kontaktach z innymi.',
    'Czuć się pewnie w grupach międzynarodowych, z przyjaciółmi lub rodziną.',
    'Uczyć się w swoim tempie, z praktycznymi przykładami i realnymi sytuacjami.',
  ],
  'image_alt' => 'Zajęcia językowe online – rozmowa i nauka w przyjaznej atmosferze',
];