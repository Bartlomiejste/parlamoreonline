<?php
return [
  'short' => 'Lekcje włoskiego i polskiego online — praktycznie, by mówić swobodnie',
];