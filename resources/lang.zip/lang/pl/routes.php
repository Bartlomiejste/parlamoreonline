<?php
return [
  'about' => 'o-mnie',
  'offer' => 'oferta',
  'reviews' => 'opinie',
  'contact' => 'kontakt',
];