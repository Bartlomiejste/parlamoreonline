<?php
return [
  'h2' => 'FAQ — szybkie odpowiedzi',
  'cta' => 'Zobacz całe FAQ',
];