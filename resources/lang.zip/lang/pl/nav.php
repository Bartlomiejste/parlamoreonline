<?php
return [
  'skip_to_content' => 'Przejdź do treści',
  'home' => 'Home',
  'about' => 'O mnie',
  'offer' => 'Oferta',
  'faq' => 'FAQ',
  'reviews' => 'Opinie',
  'contact' => 'Kontakt',
  'blog' => 'Blog',
];