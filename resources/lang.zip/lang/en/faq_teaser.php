<?php
return [
  'h2' => 'FAQ — quick answers',
  'cta' => 'See full FAQ',
];