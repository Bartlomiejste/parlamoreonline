<?php
return [
  'h2' => 'Schedule a short placement call during which we will discuss your goals and choose a course tailored to your needs.',
  'cta' => 'Schedule a call',
];