<?php
return [
  'short' => 'Online Italian and Polish lessons — practical, to help you speak fluently',
];