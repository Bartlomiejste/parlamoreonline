<?php
return [
  'skip_to_content' => 'Skip to content',
  'home' => 'Home',
  'about' => 'About',
  'offer' => 'Offer',
  'faq' => 'FAQ',
  'reviews' => 'Reviews',
  'contact' => 'Contact',
  'blog' => 'Blog',
];