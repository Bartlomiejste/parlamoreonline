<?php
return [
  'about' => 'about',
  'offer' => 'offer',
  'reviews' => 'reviews',
  'contact' => 'contact',
];