<?php
return [
  'about' => 'chi-sono',
  'offer' => 'offerta',
  'reviews' => 'recensioni',
  'contact' => 'contatto',
];