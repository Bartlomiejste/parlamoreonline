<?php
return [
  'h2' => 'Un’offerta pensata per te',
  'cta' => 'Vai all’offerta',
  'cards' => [
    ['title'=>'Corso individuale', 'text'=>'Lezioni individuali al 100% personalizzate in base alle tue esigenze e al tuo ritmo di apprendimento.'],
    ['title'=>'Corso in coppia', 'text'=>'Lezioni in due — ideali per amici, partner o fratelli.'],
    ['title'=>'Corso di gruppo', 'text'=>'Piccoli gruppi (3–6 persone) che favoriscono la conversazione attiva.'],
  ],
];