<?php
return [
  'h2' => 'Prenota una breve chiamata di valutazione durante la quale parleremo dei tuoi obiettivi e sceglieremo il corso più adatto alle tue esigenze.',
  'cta' => 'Prenota una chiamata',
];