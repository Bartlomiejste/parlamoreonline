<?php
return [
  'skip_to_content' => 'Vai al contenuto',
  'home' => 'Home',
  'about' => 'Chi sono',
  'offer' => 'Offerta',
  'faq' => 'FAQ',
  'reviews' => 'Recensioni',
  'contact' => 'Contatto',
  'blog' => 'Blog',
];