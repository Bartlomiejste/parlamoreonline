<?php
return [
  'short' => 'Lezioni di italiano e polacco online — pratiche, per parlare con naturalezza',
];