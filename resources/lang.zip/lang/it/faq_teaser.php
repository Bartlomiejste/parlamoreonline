<?php
return [
  'h2' => 'FAQ — risposte rapide',
  'cta' => 'Vedi tutte le FAQ',
];